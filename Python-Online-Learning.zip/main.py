from flask import Flask, render_template, url_for, request, redirect


app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/verify')
def verify():
    return render_template('login.html')
    
@app.route('/login', methods=['POST'])
def submit_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if password == '':
        return render_template('login.html', popup_title="!Error", popup_message="Password is required")
    elif email == '':
        return render_template('login.html', popup_title="!Error", popup_message="Username or email is required")
    else:
        return f'Hello {email}, your password is {password} <br> Login has successfull'



@app.route('/signup', methods=['POST'])
def submit_signup():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('passw')
    copassword = request.form.get('copassw')

    if password != copassword:
        return render_template('login.html', popup_title="!Error", popup_message="Password not much")
    elif email == '' or username == '':
        return render_template('login.html', popup_title="!Error", popup_message="Username and email is required")
    else:
        
        return f'Hello {username}, your password is {password} <br> Signup has successfull'


@app.route('/index')
def index():
    return 'welcome to homepage <a href="logout">Logout</a>'

@app.route('/logout')
def logout():
    return 'you are logged out'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
